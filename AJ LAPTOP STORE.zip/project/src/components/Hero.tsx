import React from 'react';
import { ArrowRight, Play, Star, MapPin, Clock, Phone, Instagram, Facebook } from 'lucide-react';

const Hero = () => {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const scrollToProducts = () => {
    const element = document.getElementById('products');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const TikTokIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  return (
    <section id="home" className="min-h-screen bg-gradient-to-br from-black via-purple-900/20 to-blue-900/20 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-cyan-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start mb-6">
              <div className="flex items-center space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <span className="ml-2 text-gray-400 text-sm">💯 TERPERCAYA - Trusted by customers</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              AJ STORE LAPTOP
              <br />
              <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-cyan-400 bg-clip-text text-transparent">
                SIDOARJO
              </span>
            </h1>

            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-6 mb-8 border border-gray-800">
              <h2 className="text-2xl font-bold text-white mb-4">BUY-SELL SECOND HAND LAPTOPS</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-300">
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-green-400" />
                  <span>📠 WhatsApp: 082136341535</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-blue-400" />
                  <span>🕰 MON-SUN 09.00-22.00 WIB</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>💯 TRUSTWORTHY</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>💻 STOK READY</span>
                </div>
                <div className="flex items-center space-x-2">
                  <MapPin className="w-4 h-4 text-purple-400" />
                  <span>🌃 SIDOARJO KOTA</span>
                </div>
                <div className="flex items-center space-x-2">
                  <span>🌍 KIRIM SELURUH INDONESIA</span>
                </div>
              </div>
            </div>

            <p className="text-xl text-gray-300 mb-8 max-w-2xl">
              Jual beli laptop bekas berkualitas di Sidoarjo. Harga terjangkau, kondisi terjamin, 
              dan pelayanan terpercaya. Melayani pengiriman ke seluruh Indonesia.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <a 
                href="https://wa.me/6282136341535" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
              >
                <Phone className="w-5 h-5" />
                <span>WhatsApp Sekarang</span>
              </a>
              
              <button 
                onClick={scrollToProducts}
                className="border border-gray-600 hover:border-blue-400 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 hover:bg-blue-500/10"
              >
                <Play className="w-5 h-5" />
                <span>Lihat Katalog</span>
              </button>
            </div>

            {/* Social Media Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start mb-8">
              <a 
                href="https://www.instagram.com/laptopsidoarjocom/" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-6 py-3 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
              >
                <Instagram className="w-5 h-5" />
                <span>Follow Instagram</span>
              </a>

              <a 
                href="https://www.facebook.com/profile.php?id=61573500697235" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
              >
                <Facebook className="w-5 h-5" />
                <span>Follow Facebook</span>
              </a>

              <a 
                href="https://www.tiktok.com/@laptopsidoarjocom" 
                target="_blank"
                rel="noopener noreferrer"
                className="bg-black hover:bg-gray-800 text-white px-6 py-3 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 border border-gray-600"
              >
                <TikTokIcon />
                <span>Follow TikTok</span>
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-8 pt-8 border-t border-gray-800">
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-white">1000+</div>
                <div className="text-gray-400 text-sm">Laptop Tersedia</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-white">24/7</div>
                <div className="text-gray-400 text-sm">WhatsApp Support</div>
              </div>
              <div className="text-center lg:text-left">
                <div className="text-2xl md:text-3xl font-bold text-white">100%</div>
                <div className="text-gray-400 text-sm">Terpercaya</div>
              </div>
            </div>
          </div>

          {/* Right Content - Featured Laptop */}
          <div className="relative">
            <div className="relative bg-gradient-to-br from-gray-900 to-black rounded-3xl p-8 border border-gray-800 shadow-2xl">
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-3xl"></div>
              
              {/* Laptop mockup */}
              <div className="relative">
                <div className="bg-gray-800 rounded-2xl p-4 mb-6">
                  <div className="bg-black rounded-xl aspect-video flex items-center justify-center">
                    <img 
                      src="https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800" 
                      alt="Laptop Bekas Berkualitas" 
                      className="w-full h-full object-cover rounded-xl"
                    />
                  </div>
                </div>
                
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">Laptop Bekas Berkualitas</h3>
                  <p className="text-gray-400 mb-4">Berbagai Merk • Kondisi Prima • Harga Terjangkau</p>
                  <div className="text-3xl font-bold text-blue-400">Mulai {formatPrice(3500000)}</div>
                </div>
              </div>
            </div>

            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-green-500 text-white px-4 py-2 rounded-full text-sm font-semibold animate-bounce">
              Stok Ready
            </div>
            <div className="absolute -bottom-4 -left-4 bg-blue-500 text-white px-4 py-2 rounded-full text-sm font-semibold">
              Kirim Se-Indonesia
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;