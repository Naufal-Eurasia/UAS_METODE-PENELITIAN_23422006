import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const footerLinks = {
    products: [
      'Laptop Gaming Bekas',
      'Laptop Bisnis Bekas',
      'Laptop Desain Bekas',
      'Ultrabook Bekas',
      'Laptop Budget',
      'Aksesoris Laptop'
    ],
    support: [
      'Customer Service',
      'WhatsApp Support',
      'Garansi Toko',
      'Kebijakan Return',
      'Info Pengiriman',
      'FAQ'
    ],
    company: [
      'Tentang Kami',
      'Tim Kami',
      'Karir',
      'Berita',
      'Mitra',
      'Blog'
    ],
    legal: [
      'Kebijakan Privasi',
      'Syarat Layanan',
      'Kebijakan Cookie',
      'Keamanan Data',
      'Aksesibilitas',
      'Sitemap'
    ]
  };

  const TikTokIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  const socialLinks = [
    { icon: Instagram, href: 'https://www.instagram.com/laptopsidoarjocom/', label: 'Instagram' },
    { icon: Facebook, href: 'https://www.facebook.com/profile.php?id=61573500697235', label: 'Facebook' },
    { 
      icon: TikTokIcon, 
      href: 'https://www.tiktok.com/@laptopsidoarjocom', 
      label: 'TikTok' 
    },
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Youtube, href: '#', label: 'YouTube' }
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-black border-t border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-6 gap-8">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <div className="flex items-center mb-6 cursor-pointer" onClick={() => scrollToSection('home')}>
                <div className="relative w-12 h-12 mr-3">
                  {/* Gradient circle background */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-500 via-pink-500 to-purple-500 p-0.5">
                    <div className="w-full h-full rounded-full bg-black flex items-center justify-center">
                      <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                        AJ
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-white">
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                    AJ STORE LAPTOP
                  </h3>
                  <p className="text-sm text-gray-400">SIDOARJO</p>
                </div>
              </div>
              
              <p className="text-gray-400 mb-6 leading-relaxed">
                Toko laptop bekas terpercaya di Sidoarjo. Menyediakan laptop berkualitas 
                dengan harga terjangkau dan pelayanan terbaik untuk seluruh Indonesia.
              </p>

              {/* Contact Info */}
              <div className="space-y-3">
                <div className="flex items-center text-gray-400">
                  <Phone className="w-4 h-4 mr-3" />
                  <span>WhatsApp: 082136341535</span>
                </div>
                <div className="flex items-center text-gray-400">
                  <Mail className="w-4 h-4 mr-3" />
                  <span>ajstorelaptop@gmail.com</span>
                </div>
                <div className="flex items-center text-gray-400">
                  <MapPin className="w-4 h-4 mr-3" />
                  <span>Jl. Gajah Magersari RT 12, RW 04, No.31, Sidoarjo</span>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex space-x-4 mt-6">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    target={social.href.startsWith('http') ? '_blank' : '_self'}
                    rel={social.href.startsWith('http') ? 'noopener noreferrer' : ''}
                    aria-label={social.label}
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      social.label === 'Instagram' 
                        ? 'bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white'
                        : social.label === 'Facebook'
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : social.label === 'TikTok'
                        ? 'bg-black hover:bg-gray-800 text-white border border-gray-600'
                        : 'bg-gray-800 hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 text-gray-400 hover:text-white'
                    }`}
                  >
                    {typeof social.icon === 'function' ? <social.icon /> : <social.icon className="w-5 h-5" />}
                  </a>
                ))}
              </div>
            </div>

            {/* Products */}
            <div>
              <h4 className="text-white font-semibold mb-6">Produk</h4>
              <ul className="space-y-3">
                {footerLinks.products.map((link, index) => (
                  <li key={index}>
                    <button 
                      onClick={() => scrollToSection('products')}
                      className="text-gray-400 hover:text-blue-400 transition-colors text-left"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="text-white font-semibold mb-6">Dukungan</h4>
              <ul className="space-y-3">
                {footerLinks.support.map((link, index) => (
                  <li key={index}>
                    <button 
                      onClick={() => scrollToSection('contact')}
                      className="text-gray-400 hover:text-blue-400 transition-colors text-left"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company */}
            <div>
              <h4 className="text-white font-semibold mb-6">Perusahaan</h4>
              <ul className="space-y-3">
                {footerLinks.company.map((link, index) => (
                  <li key={index}>
                    <button 
                      onClick={() => scrollToSection('about')}
                      className="text-gray-400 hover:text-blue-400 transition-colors text-left"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-semibold mb-6">Legal</h4>
              <ul className="space-y-3">
                {footerLinks.legal.map((link, index) => (
                  <li key={index}>
                    <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Newsletter Signup */}
        <div className="py-8 border-t border-gray-800">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h4 className="text-xl font-bold text-white mb-2">Dapatkan Update Terbaru</h4>
              <p className="text-gray-400">
                Subscribe untuk mendapatkan info laptop terbaru dan penawaran menarik.
              </p>
            </div>
            <div className="flex space-x-4">
              <input
                type="email"
                placeholder="Masukkan email Anda"
                className="flex-1 bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
              />
              <button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="py-6 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 AJ Store Laptop Sidoarjo. Semua hak dilindungi.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Kebijakan Privasi
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Syarat Layanan
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 text-sm transition-colors">
                Pengaturan Cookie
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;