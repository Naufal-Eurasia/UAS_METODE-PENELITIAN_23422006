import React, { useState } from 'react';
import { Menu, X, ShoppingCart, Search, User, Phone, Instagram, Facebook, Heart } from 'lucide-react';

interface HeaderProps {
  cartCount?: number;
  onCartClick?: () => void;
  onWishlistClick?: () => void;
}

const Header: React.FC<HeaderProps> = ({ cartCount = 0, onCartClick, onWishlistClick }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Implement search functionality
      console.log('Searching for:', searchQuery);
      // You can add actual search logic here
      setIsSearchOpen(false);
    }
  };

  const TikTokIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  return (
    <header className="bg-black/95 backdrop-blur-md fixed w-full top-0 z-50 border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left Side - Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => scrollToSection('home')}>
            <div className="relative w-10 h-10 mr-3">
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-500 via-pink-500 to-purple-500 p-0.5">
                <div className="w-full h-full rounded-full bg-black flex items-center justify-center">
                  <div className="text-lg font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                    AJ
                  </div>
                </div>
              </div>
            </div>
            <div className="text-white hidden sm:block">
              <h1 className="text-lg font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
                AJ STORE LAPTOP
              </h1>
              <p className="text-xs text-gray-400">SIDOARJO</p>
            </div>
          </div>

          {/* Center - Action Buttons (Desktop) */}
          <div className="hidden lg:flex items-center space-x-3">
            <a 
              href="https://www.tiktok.com/@laptopsidoarjocom" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-2 bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-full transition-all duration-300 border border-gray-600 hover:border-gray-500"
            >
              <TikTokIcon />
              <span className="text-sm font-medium">TikTok</span>
            </a>
            
            <a 
              href="https://wa.me/6282136341535" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-full transition-all duration-300"
            >
              <Phone className="w-4 h-4" />
              <span className="text-sm font-medium">WhatsApp</span>
            </a>
          </div>

          {/* Right Side - Icons */}
          <div className="flex items-center space-x-4">
            {/* Search */}
            <div className="relative">
              <button
                onClick={() => setIsSearchOpen(!isSearchOpen)}
                className="p-2 text-gray-400 hover:text-white transition-colors"
              >
                <Search className="w-5 h-5" />
              </button>
              
              {isSearchOpen && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-gray-900 border border-gray-700 rounded-lg shadow-xl z-50">
                  <form onSubmit={handleSearch} className="p-4">
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Cari laptop..."
                      className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-2 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                      autoFocus
                    />
                    <button
                      type="submit"
                      className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg transition-colors"
                    >
                      Cari
                    </button>
                  </form>
                </div>
              )}
            </div>

            {/* Wishlist */}
            <button
              onClick={onWishlistClick}
              className="p-2 text-gray-400 hover:text-red-400 transition-colors"
            >
              <Heart className="w-5 h-5" />
            </button>

            {/* User */}
            <button className="p-2 text-gray-400 hover:text-white transition-colors">
              <User className="w-5 h-5" />
            </button>

            {/* Cart */}
            <button
              onClick={onCartClick}
              className="relative p-2 text-gray-400 hover:text-white transition-colors"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                  {cartCount > 99 ? '99+' : cartCount}
                </span>
              )}
            </button>

            {/* Mobile menu button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 text-white hover:text-blue-400 transition-colors"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 bg-black/95 backdrop-blur-md border-t border-gray-800">
              <button onClick={() => scrollToSection('home')} className="block px-3 py-2 text-white hover:text-blue-400 transition-colors w-full text-left">Home</button>
              <button onClick={() => scrollToSection('products')} className="block px-3 py-2 text-white hover:text-blue-400 transition-colors w-full text-left">Laptops</button>
              <button onClick={() => scrollToSection('about')} className="block px-3 py-2 text-white hover:text-blue-400 transition-colors w-full text-left">About</button>
              <button onClick={() => scrollToSection('services')} className="block px-3 py-2 text-white hover:text-blue-400 transition-colors w-full text-left">Services</button>
              <button onClick={() => scrollToSection('contact')} className="block px-3 py-2 text-white hover:text-blue-400 transition-colors w-full text-left">Contact</button>
              
              <div className="border-t border-gray-800 pt-3 mt-3">
                <a href="https://www.tiktok.com/@laptopsidoarjocom" target="_blank" rel="noopener noreferrer" className="flex items-center px-3 py-2 text-white hover:text-blue-400 transition-colors">
                  <TikTokIcon />
                  <span className="ml-2">TikTok</span>
                </a>
                <a href="https://wa.me/6282136341535" target="_blank" rel="noopener noreferrer" className="flex items-center px-3 py-2 text-green-400 hover:text-green-300 transition-colors">
                  <Phone className="w-4 h-4" />
                  <span className="ml-2">WhatsApp</span>
                </a>
                <a href="https://www.instagram.com/laptopsidoarjocom/" target="_blank" rel="noopener noreferrer" className="flex items-center px-3 py-2 text-pink-400 hover:text-pink-300 transition-colors">
                  <Instagram className="w-4 h-4" />
                  <span className="ml-2">Instagram</span>
                </a>
                <a href="https://www.facebook.com/profile.php?id=61573500697235" target="_blank" rel="noopener noreferrer" className="flex items-center px-3 py-2 text-blue-400 hover:text-blue-300 transition-colors">
                  <Facebook className="w-4 h-4" />
                  <span className="ml-2">Facebook</span>
                </a>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Search Overlay for Mobile */}
      {isSearchOpen && (
        <div className="lg:hidden fixed inset-0 bg-black/50 z-40" onClick={() => setIsSearchOpen(false)}>
          <div className="bg-gray-900 m-4 rounded-lg p-4" onClick={(e) => e.stopPropagation()}>
            <form onSubmit={handleSearch}>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari laptop..."
                className="w-full bg-gray-800 border border-gray-600 rounded-lg px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
                autoFocus
              />
              <button
                type="submit"
                className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors"
              >
                Cari
              </button>
            </form>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;