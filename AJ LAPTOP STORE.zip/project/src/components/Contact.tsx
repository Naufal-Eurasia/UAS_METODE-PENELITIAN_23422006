import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, MessageCircle, Instagram, Facebook } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Create WhatsApp message
    const whatsappMessage = `Halo AJ Store Laptop Sidoarjo!

Nama: ${formData.name}
Email: ${formData.email}
WhatsApp: ${formData.phone}
Keperluan: ${formData.subject}

Pesan:
${formData.message}

Terima kasih!`;

    // Open WhatsApp with the message
    const whatsappUrl = `https://wa.me/6282136341535?text=${encodeURIComponent(whatsappMessage)}`;
    window.open(whatsappUrl, '_blank');
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
  };

  const TikTokIcon = () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  const contactInfo = [
    {
      icon: Phone,
      title: 'WhatsApp',
      details: ['082136341535', 'Fast Response 24/7'],
      color: 'from-green-500 to-emerald-500',
      link: 'https://wa.me/6282136341535'
    },
    {
      icon: Instagram,
      title: 'Instagram',
      details: ['@laptopsidoarjocom', 'Follow untuk update terbaru'],
      color: 'from-pink-500 to-purple-500',
      link: 'https://www.instagram.com/laptopsidoarjocom/'
    },
    {
      icon: Facebook,
      title: 'Facebook',
      details: ['AJ Store Laptop Sidoarjo', 'Like & Follow untuk info terbaru'],
      color: 'from-blue-500 to-blue-600',
      link: 'https://www.facebook.com/profile.php?id=61573500697235'
    },
    {
      icon: MapPin,
      title: 'Alamat Toko',
      details: ['Jl. Gajah Magersari RT 12, RW 04, No.31', 'Sidoarjo, Jawa Timur 61211'],
      color: 'from-purple-500 to-pink-500',
      link: 'https://maps.app.goo.gl/Vx5WMuFMgQQ6e5Z66'
    },
    {
      icon: Clock,
      title: 'Jam Buka',
      details: ['Senin-Minggu: 09.00-22.00 WIB', 'WhatsApp 24 Jam'],
      color: 'from-orange-500 to-red-500'
    }
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Hubungi <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Kami
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Ada pertanyaan tentang laptop atau butuh bantuan? Tim kami siap membantu! 
            Hubungi kami melalui WhatsApp untuk respon cepat.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h3 className="text-2xl font-bold text-white mb-8">Informasi Kontak</h3>
            
            <div className="grid sm:grid-cols-2 gap-6 mb-8">
              {contactInfo.map((info, index) => (
                <div key={index} className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-800">
                  <div className={`bg-gradient-to-r ${info.color} w-12 h-12 rounded-xl flex items-center justify-center mb-4`}>
                    <info.icon className="w-6 h-6 text-white" />
                  </div>
                  <h4 className="text-lg font-semibold text-white mb-2">{info.title}</h4>
                  {info.details.map((detail, detailIndex) => (
                    <p key={detailIndex} className="text-gray-400 text-sm">{detail}</p>
                  ))}
                  {info.link && (
                    <a 
                      href={info.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block mt-2 text-blue-400 hover:text-blue-300 text-sm underline"
                    >
                      {info.title === 'WhatsApp' ? 'Chat Sekarang' : 
                       info.title === 'Instagram' ? 'Follow Instagram' : 
                       info.title === 'Facebook' ? 'Follow Facebook' :
                       'Buka di Maps'}
                    </a>
                  )}
                </div>
              ))}
            </div>

            {/* Map Placeholder */}
            <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-800">
              <h4 className="text-lg font-semibold text-white mb-4">Kunjungi Toko Kami</h4>
              <div className="bg-gray-800 rounded-xl h-64 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="w-12 h-12 text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-400">Google Maps</p>
                  <p className="text-gray-500 text-sm">Jl. Gajah Magersari RT 12, RW 04, No.31</p>
                
                  <p className="text-gray-500 text-sm">Sidoarjo, Jawa Timur</p>
                  <a 
                    href="https://maps.app.goo.gl/Vx5WMuFMgQQ6e5Z66" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block mt-2 text-blue-400 hover:text-blue-300 text-sm underline"
                  >
                    Buka di Google Maps
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800">
            <h3 className="text-2xl font-bold text-white mb-6">Kirim Pesan</h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                    Nama Lengkap *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                    placeholder="Nama lengkap Anda"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                    placeholder="email@example.com"
                  />
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-300 mb-2">
                    Nomor WhatsApp *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                    placeholder="08xxxxxxxxxx"
                  />
                </div>
                
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                    Keperluan *
                  </label>
                  <select
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  >
                    <option value="">Pilih keperluan</option>
                    <option value="Ingin Beli Laptop">Ingin Beli Laptop</option>
                    <option value="Ingin Jual Laptop">Ingin Jual Laptop</option>
                    <option value="Service Laptop">Service Laptop</option>
                    <option value="Tanya Harga">Tanya Harga</option>
                    <option value="Lainnya">Lainnya</option>
                  </select>
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                  Pesan *
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors resize-none"
                  placeholder="Ceritakan kebutuhan laptop Anda..."
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-4 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
              >
                <Send className="w-5 h-5" />
                <span>Kirim via WhatsApp</span>
              </button>
            </form>

            {/* Quick Contact Options */}
            <div className="mt-8 pt-8 border-t border-gray-800">
              <h4 className="text-lg font-semibold text-white mb-4">Kontak Cepat</h4>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <a 
                  href="https://wa.me/6282136341535"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-green-600 hover:bg-green-700 text-white py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>WhatsApp</span>
                </a>
                <a 
                  href="tel:+6282136341535"
                  className="bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  <span>Telepon</span>
                </a>
                <a 
                  href="https://www.instagram.com/laptopsidoarjocom/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-colors"
                >
                  <Instagram className="w-4 h-4" />
                  <span>Instagram</span>
                </a>
                <a 
                  href="https://www.tiktok.com/@laptopsidoarjocom"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-black hover:bg-gray-800 text-white py-3 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-colors border border-gray-600"
                >
                  <TikTokIcon />
                  <span>TikTok</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;