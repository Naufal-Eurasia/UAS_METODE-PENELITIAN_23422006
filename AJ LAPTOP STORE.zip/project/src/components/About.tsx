import React from 'react';
import { Award, Users, Truck, Shield, Clock, Globe, MapPin, Phone, Instagram, Facebook } from 'lucide-react';

const About = () => {
  const features = [
    {
      icon: Award,
      title: 'Kualitas Terjamin',
      description: 'Setiap laptop bekas telah melalui pengecekan menyeluruh untuk memastikan kualitas terbaik.'
    },
    {
      icon: Users,
      title: 'Pelayanan Expert',
      description: 'Tim teknisi berpengalaman siap membantu Anda 24/7 melalui WhatsApp.'
    },
    {
      icon: Truck,
      title: 'Pengiriman Cepat',
      description: 'Pengiriman ke seluruh Indonesia dengan packaging aman dan asuransi.'
    },
    {
      icon: Shield,
      title: 'Garansi Toko',
      description: 'Garansi toko untuk memberikan kepercayaan dan keamanan pembelian Anda.'
    },
    {
      icon: Clock,
      title: 'Buka Setiap Hari',
      description: 'Melayani Senin-Minggu jam 09.00-22.00 WIB untuk kemudahan Anda.'
    },
    {
      icon: Globe,
      title: 'Jangkauan Nasional',
      description: 'Melayani pengiriman ke seluruh Indonesia dengan sistem COD tersedia.'
    }
  ];

  const TikTokIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Mengapa Pilih <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              AJ Store Laptop Sidoarjo
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Kami bukan hanya toko laptop biasa. Kami adalah mitra teknologi terpercaya Anda, 
            berkomitmen menyediakan laptop bekas berkualitas dengan pelayanan terbaik.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
          {features.map((feature, index) => (
            <div key={index} className="group bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-blue-500/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-4">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Company Story */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-white mb-6">Cerita Kami</h3>
            <div className="space-y-4 text-gray-400 leading-relaxed">
              <p>
                AJ Store Laptop Sidoarjo didirikan dengan misi sederhana: menyediakan laptop bekas 
                berkualitas tinggi dengan harga terjangkau untuk semua kalangan. Berlokasi strategis 
                di Jl. Gajah Magersari RT 12, RW 04, No.31, Sidoarjo.
              </p>
              <p>
                Selama bertahun-tahun, kami telah melayani ribuan pelanggan di seluruh Indonesia. 
                Komitmen kami terhadap kualitas, kejujuran, dan kepuasan pelanggan tetap menjadi 
                prioritas utama dalam setiap transaksi.
              </p>
              <p>
                Hari ini, kami bermitra dengan berbagai supplier terpercaya untuk menghadirkan 
                laptop bekas dari berbagai merek ternama, mulai dari laptop gaming, bisnis, 
                hingga ultrabook dengan kondisi prima dan harga bersahabat.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mt-8 pt-8 border-t border-gray-800">
              <div>
                <div className="text-3xl font-bold text-blue-400 mb-2">10,000+</div>
                <div className="text-gray-400">Pelanggan Puas</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-400 mb-2">1,000+</div>
                <div className="text-gray-400">Model Laptop</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-cyan-400 mb-2">34</div>
                <div className="text-gray-400">Provinsi Terjangkau</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-400 mb-2">100%</div>
                <div className="text-gray-400">Terpercaya</div>
              </div>
            </div>

            {/* Social Media Links */}
            <div className="mt-8 pt-8 border-t border-gray-800">
              <h4 className="text-lg font-semibold text-white mb-4">Follow Kami</h4>
              <div className="flex flex-wrap gap-4">
                <a 
                  href="https://www.instagram.com/laptopsidoarjocom/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-all duration-300 transform hover:scale-105"
                >
                  <Instagram className="w-5 h-5" />
                  <span>Instagram</span>
                </a>
                <a 
                  href="https://www.facebook.com/profile.php?id=61573500697235" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-all duration-300 transform hover:scale-105"
                >
                  <Facebook className="w-5 h-5" />
                  <span>Facebook</span>
                </a>
                <a 
                  href="https://www.tiktok.com/@laptopsidoarjocom" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="bg-black hover:bg-gray-800 text-white px-6 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-all duration-300 transform hover:scale-105 border border-gray-600"
                >
                  <TikTokIcon />
                  <span>TikTok</span>
                </a>
                <button 
                  onClick={scrollToContact}
                  className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-xl font-semibold flex items-center space-x-2 transition-colors"
                >
                  <Phone className="w-5 h-5" />
                  <span>Hubungi Kami</span>
                </button>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="bg-gradient-to-br from-gray-900 to-black rounded-3xl p-8 border border-gray-800">
              <img 
                src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800" 
                alt="Toko AJ Store Laptop Sidoarjo" 
                className="w-full h-80 object-cover rounded-2xl mb-6"
              />
              <div className="text-center">
                <h4 className="text-xl font-bold text-white mb-2">Lokasi Toko Kami</h4>
                <div className="text-gray-400 space-y-1">
                  <p className="flex items-center justify-center space-x-2">
                    <MapPin className="w-4 h-4" />
                    <span>Jl. Gajah Magersari RT 12, RW 04, No.31</span>
                  </p>
                  <p>Sidoarjo, Jawa Timur 61211</p>
                  <p className="flex items-center justify-center space-x-2">
                    <Phone className="w-4 h-4" />
                    <span>WhatsApp: 082136341535</span>
                  </p>
                  <p className="flex items-center justify-center space-x-2">
                    <Clock className="w-4 h-4" />
                    <span>MON-SUN 09.00-22.00 WIB</span>
                  </p>
                </div>
                <div className="mt-4 space-y-2">
                  <a 
                    href="https://maps.app.goo.gl/Vx5WMuFMgQQ6e5Z66" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-block text-blue-400 hover:text-blue-300 text-sm underline"
                  >
                    Buka di Google Maps
                  </a>
                  <br />
                  <div className="flex justify-center space-x-4">
                    <a 
                      href="https://www.instagram.com/laptopsidoarjocom/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-block text-pink-400 hover:text-pink-300 text-sm underline"
                    >
                      @laptopsidoarjocom
                    </a>
                    <a 
                      href="https://www.facebook.com/profile.php?id=61573500697235" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-block text-blue-400 hover:text-blue-300 text-sm underline"
                    >
                      Facebook
                    </a>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Floating testimonial */}
            <div className="absolute -bottom-6 -left-6 bg-green-500 text-white p-4 rounded-2xl max-w-xs">
              <p className="text-sm mb-2">"Laptop berkualitas, harga terjangkau, pelayanan ramah!"</p>
              <div className="text-xs opacity-80">- Budi S., Pelanggan Setia</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;