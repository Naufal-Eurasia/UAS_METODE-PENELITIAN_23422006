import React, { useState } from 'react';
import { Heart, ShoppingCart, Star, X, Plus, Minus, Eye, MessageCircle } from 'lucide-react';

interface Laptop {
  id: number;
  name: string;
  brand: string;
  category: string;
  year: number;
  price: number;
  originalPrice: number;
  image: string;
  processor: string;
  memory: string;
  storage: string;
  display: string;
  condition: string;
  rating: number;
  reviews: number;
  features: string[];
  description: string;
}

interface CartItem extends Laptop {
  quantity: number;
}

interface Notification {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}

const Products = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedLaptop, setSelectedLaptop] = useState<Laptop | null>(null);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(price);
  };

  const addNotification = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Date.now();
    const notification = { id, message, type };
    setNotifications(prev => [...prev, notification]);
    
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 3000);
  };

  const removeNotification = (id: number) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const addToCart = (laptop: Laptop) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === laptop.id);
      if (existingItem) {
        addNotification(`Quantity ${laptop.name} ditambah di keranjang`, 'info');
        return prevCart.map(item =>
          item.id === laptop.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        addNotification(`${laptop.name} ditambahkan ke keranjang`, 'success');
        return [...prevCart, { ...laptop, quantity: 1 }];
      }
    });
  };

  const removeFromCart = (laptopId: number) => {
    setCart(prevCart => {
      const item = prevCart.find(item => item.id === laptopId);
      if (item) {
        addNotification(`${item.name} dihapus dari keranjang`, 'info');
      }
      return prevCart.filter(item => item.id !== laptopId);
    });
  };

  const updateCartQuantity = (laptopId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(laptopId);
      return;
    }
    
    setCart(prevCart =>
      prevCart.map(item =>
        item.id === laptopId
          ? { ...item, quantity: newQuantity }
          : item
      )
    );
  };

  const toggleWishlist = (laptopId: number) => {
    setWishlist(prevWishlist => {
      const laptop = laptops.find(l => l.id === laptopId);
      if (prevWishlist.includes(laptopId)) {
        addNotification(`${laptop?.name} dihapus dari wishlist`, 'info');
        return prevWishlist.filter(id => id !== laptopId);
      } else {
        addNotification(`${laptop?.name} ditambahkan ke wishlist`, 'success');
        return [...prevWishlist, laptopId];
      }
    });
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getTotalItems = () => {
    return cart.reduce((total, item) => total + item.quantity, 0);
  };

  const sendCartToWhatsApp = () => {
    if (cart.length === 0) {
      addNotification('Keranjang kosong', 'error');
      return;
    }

    const cartItems = cart.map(item => 
      `• ${item.name}\n  Qty: ${item.quantity}\n  Harga: ${formatPrice(item.price)}\n  Subtotal: ${formatPrice(item.price * item.quantity)}`
    ).join('\n\n');

    const message = `Halo AJ Store Laptop Sidoarjo!

Saya ingin memesan laptop berikut:

${cartItems}

Total: ${formatPrice(getTotalPrice())}

Mohon konfirmasi ketersediaan dan proses pemesanan.

Terima kasih!`;

    const whatsappUrl = `https://wa.me/6282136341535?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    addNotification('Pesanan dikirim via WhatsApp', 'success');
  };

  const laptops: Laptop[] = [
    {
      id: 1,
      name: 'ThinkPad X1 Carbon',
      brand: 'Lenovo',
      category: 'Business',
      year: 2023,
      price: 8500000,
      originalPrice: 11000000,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1165G7',
      memory: '16GB LPDDR4x',
      storage: '512GB SSD',
      display: '14" FHD IPS',
      condition: 'Sangat Baik',
      rating: 4.8,
      reviews: 234,
      features: ['Ultrabook', 'Business Grade', 'Carbon Fiber'],
      description: 'Laptop bisnis premium dengan build quality terbaik dan performa tinggi.'
    },
    {
      id: 2,
      name: 'MacBook Air M1',
      brand: 'Apple',
      category: 'Ultrabook',
      year: 2022,
      price: 12500000,
      originalPrice: 15000000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Apple M1 Chip',
      memory: '8GB Unified Memory',
      storage: '256GB SSD',
      display: '13.3" Retina',
      condition: 'Sangat Baik',
      rating: 4.9,
      reviews: 456,
      features: ['M1 Chip', 'Retina Display', 'All-day Battery'],
      description: 'MacBook Air dengan chip M1 yang revolusioner, performa luar biasa dengan efisiensi energi tinggi.'
    },
    {
      id: 3,
      name: 'ROG Strix G15',
      brand: 'ASUS',
      category: 'Gaming',
      year: 2023,
      price: 15000000,
      originalPrice: 18000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 7 5800H',
      memory: '16GB DDR4',
      storage: '1TB SSD',
      display: '15.6" FHD 144Hz',
      condition: 'Baik',
      rating: 4.7,
      reviews: 189,
      features: ['Gaming RGB', '144Hz Display', 'RTX 3060'],
      description: 'Laptop gaming powerful dengan RTX 3060 dan layar 144Hz untuk pengalaman gaming terbaik.'
    },
    {
      id: 4,
      name: 'XPS 13',
      brand: 'Dell',
      category: 'Ultrabook',
      year: 2022,
      price: 9500000,
      originalPrice: 12000000,
      image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB LPDDR4x',
      storage: '256GB SSD',
      display: '13.4" FHD+',
      condition: 'Sangat Baik',
      rating: 4.6,
      reviews: 312,
      features: ['InfinityEdge Display', 'Premium Build', 'Compact'],
      description: 'Ultrabook premium dengan desain elegan dan layar InfinityEdge yang memukau.'
    },
    {
      id: 5,
      name: 'Pavilion Gaming',
      brand: 'HP',
      category: 'Gaming',
      year: 2022,
      price: 7500000,
      originalPrice: 9500000,
      image: 'https://images.pexels.com/photos/1714208/pexels-photo-1714208.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-10300H',
      memory: '8GB DDR4',
      storage: '512GB SSD',
      display: '15.6" FHD',
      condition: 'Baik',
      rating: 4.4,
      reviews: 156,
      features: ['Gaming Performance', 'Backlit Keyboard', 'GTX 1650'],
      description: 'Laptop gaming entry-level dengan performa solid untuk gaming dan multitasking.'
    },
    {
      id: 6,
      name: 'Surface Laptop 4',
      brand: 'Microsoft',
      category: 'Ultrabook',
      year: 2023,
      price: 11000000,
      originalPrice: 14000000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 5 4680U',
      memory: '8GB LPDDR4x',
      storage: '256GB SSD',
      display: '13.5" PixelSense',
      condition: 'Sangat Baik',
      rating: 4.5,
      reviews: 278,
      features: ['PixelSense Display', 'Premium Design', 'Touch Screen'],
      description: 'Laptop premium Microsoft dengan layar sentuh PixelSense dan desain yang elegan.'
    },
    {
      id: 7,
      name: 'IdeaPad Gaming 3',
      brand: 'Lenovo',
      category: 'Gaming',
      year: 2022,
      price: 6500000,
      originalPrice: 8500000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 5 5600H',
      memory: '8GB DDR4',
      storage: '512GB SSD',
      display: '15.6" FHD 120Hz',
      condition: 'Baik',
      rating: 4.3,
      reviews: 134,
      features: ['120Hz Display', 'Gaming Performance', 'GTX 1650'],
      description: 'Laptop gaming affordable dengan performa yang handal untuk gaming casual.'
    },
    {
      id: 8,
      name: 'ZenBook 14',
      brand: 'ASUS',
      category: 'Ultrabook',
      year: 2023,
      price: 8000000,
      originalPrice: 10500000,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB LPDDR4x',
      storage: '512GB SSD',
      display: '14" FHD',
      condition: 'Sangat Baik',
      rating: 4.6,
      reviews: 198,
      features: ['Lightweight', 'NumberPad 2.0', 'Premium Build'],
      description: 'Ultrabook stylish dengan NumberPad 2.0 dan performa yang excellent untuk produktivitas.'
    },
    {
      id: 9,
      name: 'Inspiron 15 3000',
      brand: 'Dell',
      category: 'Budget',
      year: 2022,
      price: 4500000,
      originalPrice: 6000000,
      image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i3-1115G4',
      memory: '4GB DDR4',
      storage: '256GB SSD',
      display: '15.6" HD',
      condition: 'Baik',
      rating: 4.1,
      reviews: 89,
      features: ['Budget Friendly', 'Reliable', 'Everyday Use'],
      description: 'Laptop budget yang reliable untuk kebutuhan sehari-hari dan pekerjaan ringan.'
    },
    {
      id: 10,
      name: 'Predator Helios 300',
      brand: 'Acer',
      category: 'Gaming',
      year: 2023,
      price: 16500000,
      originalPrice: 20000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-11800H',
      memory: '16GB DDR4',
      storage: '1TB SSD',
      display: '15.6" FHD 165Hz',
      condition: 'Sangat Baik',
      rating: 4.8,
      reviews: 267,
      features: ['165Hz Display', 'RTX 3070', 'Advanced Cooling'],
      description: 'Laptop gaming high-end dengan RTX 3070 dan layar 165Hz untuk gaming kompetitif.'
    },
    {
      id: 11,
      name: 'Vivobook S14',
      brand: 'ASUS',
      category: 'Budget',
      year: 2022,
      price: 5500000,
      originalPrice: 7000000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB DDR4',
      storage: '256GB SSD',
      display: '14" FHD',
      condition: 'Baik',
      rating: 4.2,
      reviews: 145,
      features: ['Colorful Design', 'Lightweight', 'Good Performance'],
      description: 'Laptop stylish dengan performa yang baik untuk mahasiswa dan pekerja muda.'
    },
    {
      id: 12,
      name: 'Latitude 7420',
      brand: 'Dell',
      category: 'Business',
      year: 2023,
      price: 10500000,
      originalPrice: 13500000,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1185G7',
      memory: '16GB DDR4',
      storage: '512GB SSD',
      display: '14" FHD',
      condition: 'Sangat Baik',
      rating: 4.7,
      reviews: 203,
      features: ['Business Grade', 'Security Features', 'Durable'],
      description: 'Laptop bisnis premium dengan fitur keamanan tingkat enterprise dan build quality terbaik.'
    },
    {
      id: 13,
      name: 'Legion 5 Pro',
      brand: 'Lenovo',
      category: 'Gaming',
      year: 2023,
      price: 18000000,
      originalPrice: 22000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 7 5800H',
      memory: '16GB DDR4',
      storage: '1TB SSD',
      display: '16" QHD 165Hz',
      condition: 'Sangat Baik',
      rating: 4.9,
      reviews: 345,
      features: ['QHD 165Hz', 'RTX 3070', 'Legion Coldfront'],
      description: 'Laptop gaming flagship dengan layar QHD 165Hz dan performa gaming terdepan.'
    },
    {
      id: 14,
      name: 'Envy x360',
      brand: 'HP',
      category: 'Ultrabook',
      year: 2022,
      price: 7000000,
      originalPrice: 9000000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 5 5500U',
      memory: '8GB DDR4',
      storage: '256GB SSD',
      display: '13.3" FHD Touch',
      condition: 'Baik',
      rating: 4.4,
      reviews: 167,
      features: ['2-in-1 Convertible', 'Touch Screen', 'Stylus Support'],
      description: 'Laptop convertible 2-in-1 dengan layar sentuh dan fleksibilitas tinggi untuk berbagai kebutuhan.'
    },
    {
      id: 15,
      name: 'Swift 3',
      brand: 'Acer',
      category: 'Budget',
      year: 2022,
      price: 5000000,
      originalPrice: 6500000,
      image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB DDR4',
      storage: '256GB SSD',
      display: '14" FHD',
      condition: 'Baik',
      rating: 4.3,
      reviews: 123,
      features: ['Lightweight', 'Fast Boot', 'Good Battery'],
      description: 'Laptop ringan dengan performa yang solid untuk produktivitas sehari-hari.'
    },
    {
      id: 16,
      name: 'ThinkBook 14',
      brand: 'Lenovo',
      category: 'Business',
      year: 2023,
      price: 6500000,
      originalPrice: 8500000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB DDR4',
      storage: '512GB SSD',
      display: '14" FHD',
      condition: 'Sangat Baik',
      rating: 4.5,
      reviews: 178,
      features: ['Modern Design', 'Business Features', 'Good Performance'],
      description: 'Laptop bisnis modern dengan desain yang fresh dan fitur produktivitas yang lengkap.'
    },
    {
      id: 17,
      name: 'Nitro 5',
      brand: 'Acer',
      category: 'Gaming',
      year: 2022,
      price: 8500000,
      originalPrice: 11000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-10300H',
      memory: '8GB DDR4',
      storage: '512GB SSD',
      display: '15.6" FHD 144Hz',
      condition: 'Baik',
      rating: 4.4,
      reviews: 234,
      features: ['144Hz Display', 'GTX 1660 Ti', 'CoolBoost'],
      description: 'Laptop gaming populer dengan performa yang handal dan harga yang kompetitif.'
    },
    {
      id: 18,
      name: 'Gram 17',
      brand: 'LG',
      category: 'Ultrabook',
      year: 2023,
      price: 13500000,
      originalPrice: 16500000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1165G7',
      memory: '16GB LPDDR4x',
      storage: '512GB SSD',
      display: '17" WQXGA',
      condition: 'Sangat Baik',
      rating: 4.6,
      reviews: 156,
      features: ['Ultra Lightweight', 'Large Display', 'Long Battery'],
      description: 'Laptop 17 inci paling ringan di kelasnya dengan layar besar dan mobilitas tinggi.'
    },
    {
      id: 19,
      name: 'ProBook 450',
      brand: 'HP',
      category: 'Business',
      year: 2022,
      price: 7500000,
      originalPrice: 9500000,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB DDR4',
      storage: '256GB SSD',
      display: '15.6" FHD',
      condition: 'Baik',
      rating: 4.3,
      reviews: 189,
      features: ['Business Reliable', 'Security Features', 'Expandable'],
      description: 'Laptop bisnis yang reliable dengan fitur keamanan dan kemudahan upgrade.'
    },
    {
      id: 20,
      name: 'MateBook D15',
      brand: 'Huawei',
      category: 'Budget',
      year: 2022,
      price: 5500000,
      originalPrice: 7500000,
      image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB DDR4',
      storage: '256GB SSD',
      display: '15.6" FHD',
      condition: 'Baik',
      rating: 4.2,
      reviews: 134,
      features: ['FullView Display', 'Fast Charging', 'Fingerprint'],
      description: 'Laptop dengan layar FullView dan fitur fast charging untuk produktivitas maksimal.'
    },
    {
      id: 21,
      name: 'TUF Gaming A15',
      brand: 'ASUS',
      category: 'Gaming',
      year: 2023,
      price: 9500000,
      originalPrice: 12000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 5 5600H',
      memory: '8GB DDR4',
      storage: '512GB SSD',
      display: '15.6" FHD 144Hz',
      condition: 'Sangat Baik',
      rating: 4.5,
      reviews: 267,
      features: ['Military Grade', '144Hz Display', 'Self-Cleaning Cooling'],
      description: 'Laptop gaming tahan banting dengan sertifikasi military grade dan cooling yang excellent.'
    },
    {
      id: 22,
      name: 'Aspire 5',
      brand: 'Acer',
      category: 'Budget',
      year: 2022,
      price: 4000000,
      originalPrice: 5500000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i3-1115G4',
      memory: '4GB DDR4',
      storage: '256GB SSD',
      display: '15.6" FHD',
      condition: 'Baik',
      rating: 4.0,
      reviews: 98,
      features: ['Entry Level', 'Reliable', 'Upgradeable'],
      description: 'Laptop entry level yang reliable untuk kebutuhan dasar dan dapat di-upgrade.'
    },
    {
      id: 23,
      name: 'EliteBook 840',
      brand: 'HP',
      category: 'Business',
      year: 2023,
      price: 12000000,
      originalPrice: 15000000,
      image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1165G7',
      memory: '16GB DDR4',
      storage: '512GB SSD',
      display: '14" FHD',
      condition: 'Sangat Baik',
      rating: 4.7,
      reviews: 234,
      features: ['Enterprise Grade', 'Security Suite', 'Premium Build'],
      description: 'Laptop bisnis enterprise dengan fitur keamanan lengkap dan build quality premium.'
    },
    {
      id: 24,
      name: 'IdeaPad 3',
      brand: 'Lenovo',
      category: 'Budget',
      year: 2022,
      price: 4500000,
      originalPrice: 6000000,
      image: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 3 5300U',
      memory: '4GB DDR4',
      storage: '256GB SSD',
      display: '15.6" HD',
      condition: 'Baik',
      rating: 4.1,
      reviews: 156,
      features: ['Budget Friendly', 'AMD Ryzen', 'Everyday Use'],
      description: 'Laptop budget dengan processor AMD Ryzen yang efficient untuk penggunaan sehari-hari.'
    },
    {
      id: 25,
      name: 'Creator Z16',
      brand: 'MSI',
      category: 'Design',
      year: 2023,
      price: 22000000,
      originalPrice: 27000000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-11800H',
      memory: '32GB DDR4',
      storage: '1TB SSD',
      display: '16" QHD+ Touch',
      condition: 'Sangat Baik',
      rating: 4.8,
      reviews: 189,
      features: ['Creator Focused', 'QHD+ Touch', 'RTX 3060'],
      description: 'Laptop untuk content creator dengan layar QHD+ touch dan performa tinggi untuk editing.'
    },
    {
      id: 26,
      name: 'Yoga Slim 7',
      brand: 'Lenovo',
      category: 'Ultrabook',
      year: 2023,
      price: 9000000,
      originalPrice: 11500000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 7 5700U',
      memory: '16GB LPDDR4x',
      storage: '512GB SSD',
      display: '14" 2.2K',
      condition: 'Sangat Baik',
      rating: 4.6,
      reviews: 178,
      features: ['2.2K Display', 'Premium Design', 'Fast Performance'],
      description: 'Ultrabook premium dengan layar 2.2K dan performa AMD Ryzen yang excellent.'
    },
    {
      id: 27,
      name: 'Spectre x360',
      brand: 'HP',
      category: 'Ultrabook',
      year: 2023,
      price: 14500000,
      originalPrice: 18000000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1165G7',
      memory: '16GB LPDDR4x',
      storage: '512GB SSD',
      display: '13.5" 3K2K Touch',
      condition: 'Sangat Baik',
      rating: 4.8,
      reviews: 267,
      features: ['360° Convertible', '3K2K Touch', 'Premium Materials'],
      description: 'Laptop convertible premium dengan layar 3K2K touch dan material berkualitas tinggi.'
    },
    {
      id: 28,
      name: 'ROG Flow X13',
      brand: 'ASUS',
      category: 'Gaming',
      year: 2023,
      price: 17500000,
      originalPrice: 21000000,
      image: 'https://images.pexels.com/photos/777001/pexels-photo-777001.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'AMD Ryzen 9 5900HS',
      memory: '16GB LPDDR4x',
      storage: '1TB SSD',
      display: '13.4" FHD 120Hz',
      condition: 'Sangat Baik',
      rating: 4.7,
      reviews: 145,
      features: ['Convertible Gaming', '120Hz Touch', 'eGPU Ready'],
      description: 'Laptop gaming convertible unik dengan kemampuan eGPU dan performa tinggi dalam form factor compact.'
    },
    {
      id: 29,
      name: 'Surface Pro 8',
      brand: 'Microsoft',
      category: 'Ultrabook',
      year: 2023,
      price: 13000000,
      originalPrice: 16000000,
      image: 'https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i5-1135G7',
      memory: '8GB LPDDR4x',
      storage: '256GB SSD',
      display: '13" PixelSense Flow',
      condition: 'Sangat Baik',
      rating: 4.5,
      reviews: 234,
      features: ['2-in-1 Tablet', 'PixelSense Flow', 'Surface Pen'],
      description: 'Tablet 2-in-1 premium dengan layar PixelSense Flow dan dukungan Surface Pen untuk produktivitas maksimal.'
    },
    {
      id: 30,
      name: 'Galaxy Book2 Pro',
      brand: 'Samsung',
      category: 'Ultrabook',
      year: 2023,
      price: 11500000,
      originalPrice: 14500000,
      image: 'https://images.pexels.com/photos/1029757/pexels-photo-1029757.jpeg?auto=compress&cs=tinysrgb&w=800',
      processor: 'Intel Core i7-1260P',
      memory: '16GB LPDDR5',
      storage: '512GB SSD',
      display: '15.6" AMOLED',
      condition: 'Sangat Baik',
      rating: 4.6,
      reviews: 198,
      features: ['AMOLED Display', 'Ultra Lightweight', 'Galaxy Ecosystem'],
      description: 'Laptop premium dengan layar AMOLED yang stunning dan integrasi sempurna dengan ekosistem Galaxy.'
    }
  ];

  const categories = ['All', 'Gaming', 'Business', 'Ultrabook', 'Budget', 'Design'];

  const filteredLaptops = selectedCategory === 'All' 
    ? laptops 
    : laptops.filter(laptop => laptop.category === selectedCategory);

  const isInCart = (laptopId: number) => cart.some(item => item.id === laptopId);
  const isInWishlist = (laptopId: number) => wishlist.includes(laptopId);

  return (
    <section id="products" className="py-20 bg-gradient-to-b from-gray-900 to-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Notifications */}
        <div className="fixed top-20 right-4 z-50 space-y-2">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className={`animate-slide-in p-4 rounded-lg shadow-lg max-w-sm ${
                notification.type === 'success' ? 'bg-green-600' :
                notification.type === 'error' ? 'bg-red-600' : 'bg-blue-600'
              } text-white`}
            >
              <div className="flex items-center justify-between">
                <p className="text-sm">{notification.message}</p>
                <button
                  onClick={() => removeNotification(notification.id)}
                  className="ml-2 text-white hover:text-gray-200"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Koleksi <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Laptop Bekas
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Pilihan laptop bekas berkualitas dari berbagai brand ternama dengan harga terjangkau 
            dan garansi toko. Semua laptop telah melalui quality check ketat.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredLaptops.map((laptop) => (
            <div key={laptop.id} className="group bg-gray-900/50 backdrop-blur-sm rounded-2xl overflow-hidden border border-gray-800 hover:border-blue-500/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className="relative">
                <img 
                  src={laptop.image} 
                  alt={laptop.name}
                  className="w-full h-48 object-cover"
                />
                
                {/* Overlay with actions */}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-4">
                  <button
                    onClick={() => setSelectedLaptop(laptop)}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-full transition-colors"
                  >
                    <Eye className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => toggleWishlist(laptop.id)}
                    className={`p-3 rounded-full transition-colors ${
                      isInWishlist(laptop.id)
                        ? 'bg-red-600 hover:bg-red-700 text-white'
                        : 'bg-gray-600 hover:bg-gray-700 text-white'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isInWishlist(laptop.id) ? 'fill-current' : ''}`} />
                  </button>
                  <button
                    onClick={() => addToCart(laptop)}
                    className={`p-3 rounded-full transition-colors ${
                      isInCart(laptop.id)
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : 'bg-purple-600 hover:bg-purple-700 text-white'
                    }`}
                  >
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>

                {/* Status badges */}
                <div className="absolute top-3 left-3 space-y-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                    laptop.condition === 'Sangat Baik' ? 'bg-green-500' : 'bg-yellow-500'
                  } text-white`}>
                    {laptop.condition}
                  </span>
                  {isInCart(laptop.id) && (
                    <span className="block px-2 py-1 rounded-full text-xs font-semibold bg-blue-500 text-white">
                      🛒 In Cart
                    </span>
                  )}
                  {isInWishlist(laptop.id) && (
                    <span className="block px-2 py-1 rounded-full text-xs font-semibold bg-red-500 text-white">
                      ❤️ Loved
                    </span>
                  )}
                </div>

                {/* Discount badge */}
                <div className="absolute top-3 right-3">
                  <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-semibold">
                    -{Math.round((1 - laptop.price / laptop.originalPrice) * 100)}%
                  </span>
                </div>
              </div>

              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-blue-400 text-sm font-semibold">{laptop.brand}</span>
                  <span className="text-gray-400 text-sm">{laptop.year}</span>
                </div>
                
                <h3 className="text-lg font-bold text-white mb-2 line-clamp-2">{laptop.name}</h3>
                
                <div className="flex items-center mb-3">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${
                          i < Math.floor(laptop.rating) 
                            ? 'fill-yellow-400 text-yellow-400' 
                            : 'text-gray-600'
                        }`} 
                      />
                    ))}
                  </div>
                  <span className="text-gray-400 text-sm ml-2">({laptop.reviews})</span>
                </div>

                <div className="space-y-1 mb-4 text-sm text-gray-400">
                  <p>💻 {laptop.processor}</p>
                  <p>🧠 {laptop.memory}</p>
                  <p>💾 {laptop.storage}</p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold text-white">{formatPrice(laptop.price)}</div>
                    <div className="text-sm text-gray-400 line-through">{formatPrice(laptop.originalPrice)}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Cart Sidebar */}
        {isCartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden">
            <div className="absolute inset-0 bg-black/50" onClick={() => setIsCartOpen(false)}></div>
            <div className="absolute right-0 top-0 h-full w-full max-w-md bg-gray-900 shadow-xl">
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-6 border-b border-gray-800">
                  <h3 className="text-xl font-bold text-white">Keranjang ({getTotalItems()})</h3>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="text-gray-400 hover:text-white"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                  {cart.length === 0 ? (
                    <p className="text-gray-400 text-center">Keranjang kosong</p>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <div key={item.id} className="flex items-center space-x-4 bg-gray-800 rounded-lg p-4">
                          <img src={item.image} alt={item.name} className="w-16 h-16 object-cover rounded" />
                          <div className="flex-1">
                            <h4 className="text-white font-semibold text-sm">{item.name}</h4>
                            <p className="text-gray-400 text-sm">{formatPrice(item.price)}</p>
                            <div className="flex items-center space-x-2 mt-2">
                              <button
                                onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                                className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="text-white text-sm">{item.quantity}</span>
                              <button
                                onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                                className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="border-t border-gray-800 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-lg font-semibold text-white">Total:</span>
                      <span className="text-xl font-bold text-blue-400">{formatPrice(getTotalPrice())}</span>
                    </div>
                    <button
                      onClick={sendCartToWhatsApp}
                      className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors"
                    >
                      <MessageCircle className="w-5 h-5" />
                      <span>Pesan via WhatsApp</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Product Modal */}
        {selectedLaptop && (
          <div className="fixed inset-0 z-50 overflow-y-auto">
            <div className="flex items-center justify-center min-h-screen px-4">
              <div className="absolute inset-0 bg-black/70" onClick={() => setSelectedLaptop(null)}></div>
              <div className="relative bg-gray-900 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <button
                  onClick={() => setSelectedLaptop(null)}
                  className="absolute top-4 right-4 z-10 bg-gray-800 hover:bg-gray-700 text-white p-2 rounded-full"
                >
                  <X className="w-6 h-6" />
                </button>

                <div className="grid md:grid-cols-2 gap-8 p-8">
                  <div>
                    <img 
                      src={selectedLaptop.image} 
                      alt={selectedLaptop.name}
                      className="w-full h-80 object-cover rounded-xl"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-blue-400 font-semibold">{selectedLaptop.brand}</span>
                      <span className="text-gray-400">{selectedLaptop.year}</span>
                    </div>

                    <h2 className="text-3xl font-bold text-white mb-4">{selectedLaptop.name}</h2>

                    <div className="flex items-center mb-6">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`w-5 h-5 ${
                              i < Math.floor(selectedLaptop.rating) 
                                ? 'fill-yellow-400 text-yellow-400' 
                                : 'text-gray-600'
                            }`} 
                          />
                        ))}
                      </div>
                      <span className="text-gray-400 ml-2">({selectedLaptop.reviews} reviews)</span>
                    </div>

                    <div className="mb-6">
                      <div className="text-3xl font-bold text-white mb-2">{formatPrice(selectedLaptop.price)}</div>
                      <div className="text-lg text-gray-400 line-through">{formatPrice(selectedLaptop.originalPrice)}</div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center text-gray-300">
                        <span className="w-20 text-gray-400">Processor:</span>
                        <span>{selectedLaptop.processor}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <span className="w-20 text-gray-400">Memory:</span>
                        <span>{selectedLaptop.memory}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <span className="w-20 text-gray-400">Storage:</span>
                        <span>{selectedLaptop.storage}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <span className="w-20 text-gray-400">Display:</span>
                        <span>{selectedLaptop.display}</span>
                      </div>
                      <div className="flex items-center text-gray-300">
                        <span className="w-20 text-gray-400">Kondisi:</span>
                        <span className="text-green-400">{selectedLaptop.condition}</span>
                      </div>
                    </div>

                    <p className="text-gray-400 mb-6">{selectedLaptop.description}</p>

                    <div className="flex flex-wrap gap-2 mb-6">
                      {selectedLaptop.features.map((feature, index) => (
                        <span key={index} className="bg-blue-600/20 text-blue-400 px-3 py-1 rounded-full text-sm">
                          {feature}
                        </span>
                      ))}
                    </div>

                    <div className="flex space-x-4">
                      <button
                        onClick={() => addToCart(selectedLaptop)}
                        className={`flex-1 py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-colors ${
                          isInCart(selectedLaptop.id)
                            ? 'bg-green-600 hover:bg-green-700 text-white'
                            : 'bg-blue-600 hover:bg-blue-700 text-white'
                        }`}
                      >
                        <ShoppingCart className="w-5 h-5" />
                        <span>{isInCart(selectedLaptop.id) ? 'In Cart' : 'Add to Cart'}</span>
                      </button>
                      
                      <button
                        onClick={() => toggleWishlist(selectedLaptop.id)}
                        className={`px-6 py-3 rounded-lg font-semibold flex items-center space-x-2 transition-colors ${
                          isInWishlist(selectedLaptop.id)
                            ? 'bg-red-600 hover:bg-red-700 text-white'
                            : 'bg-gray-600 hover:bg-gray-700 text-white'
                        }`}
                      >
                        <Heart className={`w-5 h-5 ${isInWishlist(selectedLaptop.id) ? 'fill-current' : ''}`} />
                        <span>{isInWishlist(selectedLaptop.id) ? 'Loved' : 'Love'}</span>
                      </button>

                      <a
                        href={`https://wa.me/6282136341535?text=Halo, saya tertarik dengan ${selectedLaptop.name} seharga ${formatPrice(selectedLaptop.price)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold flex items-center space-x-2 transition-colors"
                      >
                        <MessageCircle className="w-5 h-5" />
                        <span>WhatsApp</span>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Products;