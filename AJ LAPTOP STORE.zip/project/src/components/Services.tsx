import React from 'react';
import { Wrench, Headphones, RefreshCw, GraduationCap, Shield, Zap, Instagram, Facebook } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Wrench,
      title: 'Service Laptop',
      description: 'Layanan perbaikan laptop profesional untuk semua jenis kerusakan dan masalah.',
      features: ['Diagnosa Gratis', 'Perbaikan Hardware', 'Instalasi Software'],
      color: 'from-blue-500 to-cyan-500'
    },
    {
      icon: RefreshCw,
      title: 'Upgrade Laptop',
      description: 'Tingkatkan performa laptop Anda dengan upgrade RAM, SSD, dan komponen lainnya.',
      features: ['Upgrade RAM', 'Instalasi SSD', 'Optimasi Performa'],
      color: 'from-purple-500 to-pink-500'
    },
    {
      icon: Shield,
      title: 'Garansi Toko',
      description: 'Garansi toko untuk memberikan perlindungan dan kepercayaan pada pembelian Anda.',
      features: ['Garansi 3-6 Bulan', 'Perlindungan Kerusakan', 'Layanan Prioritas'],
      color: 'from-green-500 to-emerald-500'
    },
    {
      icon: GraduationCap,
      title: 'Konsultasi & Setup',
      description: 'Konsultasi pemilihan laptop dan setup awal untuk kebutuhan spesifik Anda.',
      features: ['Konsultasi Gratis', 'Setup Awal', 'Training Penggunaan'],
      color: 'from-orange-500 to-red-500'
    },
    {
      icon: Headphones,
      title: 'Customer Support',
      description: 'Tim customer service yang siap membantu Anda 24/7 melalui WhatsApp.',
      features: ['WhatsApp 24/7', 'Respon Cepat', 'Bantuan Teknis'],
      color: 'from-indigo-500 to-purple-500'
    },
    {
      icon: Zap,
      title: 'Layanan Express',
      description: 'Layanan cepat untuk kebutuhan mendesak dengan prioritas tinggi.',
      features: ['Same-day Service', 'Pengiriman Express', 'Antrian Prioritas'],
      color: 'from-yellow-500 to-orange-500'
    }
  ];

  const TikTokIcon = () => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M19.321 5.562a5.124 5.124 0 0 1-.443-.258 6.228 6.228 0 0 1-1.137-.966c-.849-.849-1.419-1.932-1.419-3.338h-3.555v14.555c0 1.849-1.506 3.355-3.355 3.355s-3.355-1.506-3.355-3.355 1.506-3.355 3.355-3.355c.185 0 .365.015.54.044V8.689a7.91 7.91 0 0 0-.54-.037c-4.355 0-7.89 3.535-7.89 7.89s3.535 7.89 7.89 7.89 7.89-3.535 7.89-7.89V9.775a9.847 9.847 0 0 0 5.733 1.848V7.968a6.234 6.234 0 0 1-3.714-2.406z" fill="url(#tiktok-gradient)"/>
      <defs>
        <linearGradient id="tiktok-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#ff0050"/>
          <stop offset="50%" stopColor="#00f2ea"/>
          <stop offset="100%" stopColor="#ff0050"/>
        </linearGradient>
      </defs>
    </svg>
  );

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-black to-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Layanan <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Kami
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto">
            Selain menjual laptop bekas berkualitas, kami juga menyediakan berbagai layanan 
            untuk memastikan Anda mendapatkan yang terbaik dari investasi teknologi Anda.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <div key={index} className="group bg-gray-900/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-800 hover:border-blue-500/50 transition-all duration-300 hover:transform hover:scale-105">
              <div className={`bg-gradient-to-r ${service.color} w-16 h-16 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <service.icon className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4">{service.title}</h3>
              <p className="text-gray-400 mb-6 leading-relaxed">{service.description}</p>
              
              <ul className="space-y-2">
                {service.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm text-gray-300">
                    <div className="w-2 h-2 bg-blue-400 rounded-full mr-3"></div>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Service Process */}
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-gray-800">
          <h3 className="text-3xl font-bold text-white text-center mb-12">Cara Kami Melayani Anda</h3>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-gradient-to-r from-blue-500 to-purple-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">1</span>
              </div>
              <h4 className="text-lg font-semibold text-white mb-2">Hubungi Kami</h4>
              <p className="text-gray-400 text-sm">Hubungi melalui WhatsApp atau datang langsung ke toko</p>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">2</span>
              </div>
              <h4 className="text-lg font-semibold text-white mb-2">Konsultasi</h4>
              <p className="text-gray-400 text-sm">Kami evaluasi kebutuhan dan rekomendasikan solusi terbaik</p>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-pink-500 to-red-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">3</span>
              </div>
              <h4 className="text-lg font-semibold text-white mb-2">Pelayanan</h4>
              <p className="text-gray-400 text-sm">Layanan profesional oleh teknisi berpengalaman</p>
            </div>
            
            <div className="text-center">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-white font-bold text-xl">4</span>
              </div>
              <h4 className="text-lg font-semibold text-white mb-2">Follow-up</h4>
              <p className="text-gray-400 text-sm">Dukungan berkelanjutan untuk memastikan kepuasan Anda</p>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <h3 className="text-2xl font-bold text-white mb-4">Butuh Bantuan dengan Laptop Anda?</h3>
          <p className="text-gray-400 mb-8">Tim ahli kami siap membantu dengan segala kebutuhan laptop Anda.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://wa.me/6282136341535?text=Halo, saya butuh bantuan dengan laptop saya"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-4 rounded-full font-semibold transition-all duration-300 transform hover:scale-105"
            >
              Hubungi WhatsApp
            </a>
            <a 
              href="https://www.instagram.com/laptopsidoarjocom/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
            >
              <Instagram className="w-5 h-5" />
              <span>Follow Instagram</span>
            </a>
            <a 
              href="https://www.facebook.com/profile.php?id=61573500697235" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105"
            >
              <Facebook className="w-5 h-5" />
              <span>Follow Facebook</span>
            </a>
            <a 
              href="https://www.tiktok.com/@laptopsidoarjocom" 
              target="_blank" 
              rel="noopener noreferrer"
              className="bg-black hover:bg-gray-800 text-white px-8 py-4 rounded-full font-semibold flex items-center justify-center space-x-2 transition-all duration-300 transform hover:scale-105 border border-gray-600"
            >
              <TikTokIcon />
              <span>Follow TikTok</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;