import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Products from './components/Products';
import About from './components/About';
import Services from './components/Services';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [cartCount, setCartCount] = useState(0);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);

  const handleCartClick = () => {
    setIsCartOpen(true);
  };

  const handleWishlistClick = () => {
    setIsWishlistOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <Header 
        cartCount={cartCount}
        onCartClick={handleCartClick}
        onWishlistClick={handleWishlistClick}
      />
      <Hero />
      <Products />
      <About />
      <Services />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;